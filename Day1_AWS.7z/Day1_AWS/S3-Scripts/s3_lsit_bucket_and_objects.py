# This script lists buckets and objects in S3 bucket using boto3 library.
import boto3

s3 = boto3.client('s3')

response = s3.list_buckets()  
print("Buckets:")

for bucket in response['Buckets']:  # For loop to iterate through the list of buckets
    print(f"  {bucket['Name']}")
    objects_response = s3.list_objects_v2(Bucket=bucket['Name'])  
    #
    if 'Contents' in objects_response:  # Check if the bucket contains any objects
        print("  Objects:") #
        
        for obj in objects_response['Contents']: # For loop to iterate through the list of objects in the bucket
            print(f"    {obj['Key']}") # Print the name of the object
           