import boto3

s3 = boto3.client('s3')

bucket_name = 'ritwikbucket2002'
object_name = 'aws_image.png'

response = s3.delete_object(Bucket = bucket_name, Key = object_name)
print(response)