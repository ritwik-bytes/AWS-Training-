# This script downloads file from S3 bucket using boto3 library.
import boto3
s3 = boto3.client('s3') # this is script for test for boto3
bucket_name = 'ritwikbucket2002' # this is script for test for boto3
object_name = 'Rits.png' # this is script for test for boto3
file_path = 'C:/Users/ritwik.mohapatra/Documents/Day1_AWS/Rits.png' # this is script for test for boto3
response = s3.download_file(bucket_name, object_name, file_path) # this is script for test for boto3
print(response) #
 
 
 