#this script provides details abt AMI ec2 using the boto3

# This script provides details of AMIs (Amazon Machine Images) in EC2 using boto3 library.
import boto3
ec2_client = boto3.client('ec2', region_name='us-east-1') # this is script for test for boto3
response = ec2_client.describe_images(
    Owners=['amazon'],
    Filters=[
        {
            'Name': 'state',
            'Values': ['available']
        }
    ]) # this is script for test for boto3
print("Available AMIs:")
for image in response['Images']:  # For loop to iterate through the list of images
    print(f"  Image ID: {image['ImageId']}")  # Print the image ID
    print(f"  Name: {image['Name']}")  # Print the image name
    print(f"  State: {image['State']}")  # Print the image state
    print(f"  Creation Date: {image['CreationDate']}")  # Print the image creation date
    print(f"  Architecture: {image['Architecture']}")  # Print the image architecture
    print(f"  Platform: {image.get('Platform', 'N/A')}")  # Print the image platform if available