#this script creates new EC2 instance using boto3 lib

import boto3
ec2 = boto3.resource('ec2') # this is script for test for boto3
response = ec2.create_instances(
    
    ImageId='ami-0b6c6ebed2801a5cb', # this is script for test for boto3
    InstanceType='t2.micro', # this is script for test for boto3
    MinCount=1, # this is script for test for boto3
    MaxCount=1, # this is script for test for boto3
    KeyName='Innovation023', # this is script for test for boto3//
    SecurityGroupIds=['sg-056cf928a522cd24b'], # this is script for test for boto3//
    SubnetId='subnet-036858f860cae8cfe' # this is script for test for boto3
) # this is script for test for boto3
print(response) # this is script for test for boto3