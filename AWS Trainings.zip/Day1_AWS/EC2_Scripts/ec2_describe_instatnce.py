# This script describes the EC2 instances using boto3 library.
import boto3

ec2 = boto3.client('ec2') # this is script for test for boto3

response = ec2.describe_instances() # this is script for test for boto3

print("EC2 Instances:")
for reservation in response['Reservations']:  # For loop to iterate through the list of reservations
    for instance in reservation['Instances']:  # For loop to iterate through the list of instances in the reservation
       
        print(f"  Instance ID: {instance['InstanceId']}")  # Print the instance ID
        print(f"  Instance Type: {instance['InstanceType']}")  # Print the instance type
        print(f"  State: {instance['State']['Name']}")  # Print the instance state
        print(f"  Public IP: {instance.get('PublicIpAddress', 'N/A')}")  # Print the public IP address if available
        print(f"  Private IP: {instance.get('PrivateIpAddress', 'N/A')}")  # Print the private IP address if available
