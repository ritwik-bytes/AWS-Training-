# This script terminates EC2 instance using boto3 library.
import boto3
ec2 = boto3.resource('ec2') # this is script for test for boto3
instance_id = 'i-085bb22e947c2bf9a' # this is script for test for boto3
response = ec2.instances.filter(InstanceIds=[instance_id]).terminate() # this is script for test for boto3
print(response) # this is script for test for boto3