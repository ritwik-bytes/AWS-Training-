import boto3 #this is the script for test for boto3

client = boto3.client('s3') #this is the script python

response = client.create_bucket(
    Bucket='ritwikbucket2002',
    ACL = 'private'
)
print(response)