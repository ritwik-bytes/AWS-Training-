# this script lists S3 buckets from AWS

import boto3 # this is script for test for boto3
client = boto3.client('s3') # this is script for test for boto3
response = client.list_buckets() # this is script for test for boto3
print(response)
 