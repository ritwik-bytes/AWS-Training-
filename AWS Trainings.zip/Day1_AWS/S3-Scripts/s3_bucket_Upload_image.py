import boto3
 
client = boto3.client('s3')
 
bucket_name = 'ritwikbucket2002'
file_path = 'C:/Users/ritwik.mohapatra/Documents/Day1_AWS/Rits.png'
object_name = 'Rits.png'
 
response = client.upload_file(file_path,bucket_name,object_name)